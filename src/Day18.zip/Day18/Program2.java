package encapsulation;

public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 45;
		int b = 75;
		int c = a+b;
		
		System.out.println(c);
	}

}
